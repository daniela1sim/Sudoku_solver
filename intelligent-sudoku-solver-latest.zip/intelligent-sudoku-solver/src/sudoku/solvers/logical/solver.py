"""Deterministic orchestration of explainable, human-style Sudoku deductions.

Technique-specific verification lives in verification.py. Additional technique
families need verifier support before they can safely be registered.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from collections.abc import Iterable

from sudoku.core.board import SudokuBoard
from sudoku.core.candidates import CandidateState
from sudoku.core.deduction import Deduction
from sudoku.solvers.logical.base import LogicalTechnique
from sudoku.solvers.logical.singles import HiddenSingle, NakedSingle
from sudoku.solvers.logical.subsets import (NakedPair, HiddenPair, NakedTriple, HiddenTriple, NakedQuad, HiddenQuad)
from sudoku.solvers.logical.verification import DeductionVerifier


class SolveStatus(str, Enum):
    SOLVED = "solved"
    STUCK = "stuck"
    STEP_LIMIT = "step_limit"


@dataclass(frozen=True, slots=True)
class SolveStep:
    """One verified deduction plus reproducible states before and after it."""

    deduction: Deduction
    before: CandidateState
    after: CandidateState


@dataclass(frozen=True, slots=True)
class SolveResult:
    """A snapshot of the final state and the deductions used to reach it."""

    status: SolveStatus
    state: CandidateState
    steps: tuple[SolveStep, ...]

    @property
    def solved(self) -> bool:
        return self.status is SolveStatus.SOLVED


class LogicalSolver:
    """Apply one verified deduction at a time, respecting technique priority.

    The input board/state is copied; solving never changes the caller's input.
    A step is committed only after all its effects have succeeded on a copy.

    Only registered techniques with independent mathematical verification are accepted.
    """

    def __init__(self, techniques: Iterable[LogicalTechnique] | None = None) -> None:
        if techniques is None:
            techniques = (NakedSingle(), HiddenSingle(), NakedPair(), HiddenPair(),
                          NakedTriple(), HiddenTriple(), NakedQuad(), HiddenQuad())
        self.techniques = tuple(techniques)
        if any(not isinstance(t, LogicalTechnique) for t in self.techniques):
            raise TypeError("techniques must contain LogicalTechnique instances")
        if any(not DeductionVerifier.supports(t) for t in self.techniques):
            raise NotImplementedError("Some registered techniques do not have verifiers")

    def solve(
        self,
        puzzle: SudokuBoard | CandidateState,
        *,
        max_steps: int | None = None,
    ) -> SolveResult:
        """Solve until complete, stuck, or the optional deduction step limit is hit.

        ``max_steps=0`` inspects the initial state without making any moves.
        No guessing or backtracking is performed.
        """
        if isinstance(puzzle, CandidateState):
            state = puzzle.copy()
        elif isinstance(puzzle, SudokuBoard):
            state = CandidateState(puzzle)
        else:
            raise TypeError("puzzle must be SudokuBoard or CandidateState")
        if max_steps is not None and (type(max_steps) is not int or max_steps < 0):
            raise ValueError("max_steps must be a nonnegative integer or None")

        history: list[SolveStep] = []
        while True:
            if state.is_complete():
                status = SolveStatus.SOLVED
                break
            if max_steps is not None and len(history) >= max_steps:
                status = SolveStatus.STEP_LIMIT
                break

            selected: tuple[LogicalTechnique, Deduction] | None = None
            for technique in self.techniques:
                proposed = technique.find_first(state)
                if proposed is not None:
                    selected = (technique, proposed)
                    break
            if selected is None:
                status = SolveStatus.STUCK
                break

            technique, deduction = selected
            DeductionVerifier.verify(state, technique, deduction)
            candidate = state.copy()
            for move in deduction.placements:
                candidate.place(*move.cell, move.digit)
            for move in deduction.eliminations:
                candidate.eliminate(*move.cell, move.digit)
            history.append(SolveStep(deduction, state.copy(), candidate.copy()))
            state = candidate

        return SolveResult(status, state.copy(), tuple(history))
