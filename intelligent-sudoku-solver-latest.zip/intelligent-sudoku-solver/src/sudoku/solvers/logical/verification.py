"""Technique-specific validation of proposed Sudoku deductions.

Verification checks that the proposed effects follow from the *current*
CandidateState. Premise descriptions are explanatory annotations and are not
yet machine-checked proof certificates.

Supported techniques include singles and naked/hidden subsets of size 2–4.
"""

from __future__ import annotations

from sudoku.core.candidates import CandidateState
from sudoku.core.deduction import Deduction
from sudoku.solvers.logical.base import LogicalTechnique
from sudoku.solvers.logical.singles import HiddenSingle, NakedSingle, _units
from sudoku.solvers.logical.subsets import (
    HiddenSubset, NakedSubset, HiddenPair, NakedPair,
    HiddenTriple, NakedTriple, HiddenQuad, NakedQuad,
)


class DeductionVerifier:
    """Check deductions without mutating the solving state."""

    _SUPPORTED = (NakedSingle, HiddenSingle, NakedSubset, HiddenSubset,
                  NakedPair, HiddenPair, NakedTriple, HiddenTriple, NakedQuad, HiddenQuad)

    @classmethod
    def supports(cls, technique: LogicalTechnique) -> bool:
        """Whether this exact technique implementation has a verifier."""
        return type(technique) in cls._SUPPORTED

    @classmethod
    def verify(
        cls, state: CandidateState, technique: LogicalTechnique, deduction: Deduction
    ) -> None:
        """Raise ValueError for an invalid deduction, or NotImplementedError if unsupported.

        Success is indicated by returning None. This method does not mutate state.
        """
        if not cls.supports(technique):
            raise NotImplementedError(f"No verifier for {type(technique).__name__}")
        if isinstance(technique, (NakedSubset, HiddenSubset)):
            cls._verify_subset(state, technique, deduction)
            return
        if (
            deduction.technique != technique.name
            or len(deduction.placements) != 1
            or deduction.eliminations
        ):
            raise ValueError("Unexpected deduction shape or technique name")

        placement = deduction.placements[0]
        row, col = placement.cell
        digit = placement.digit
        if digit not in state.candidates_at(row, col):
            raise ValueError("Placement digit is not an available candidate")

        if type(technique) is NakedSingle:
            if state.candidates_at(row, col) != frozenset({digit}):
                raise ValueError("Invalid Naked Single")
        elif type(technique) is HiddenSingle:
            row_cells = ((row, c) for c in range(9))
            col_cells = ((r, col) for r in range(9))
            box_row = (row // 3) * 3
            box_col = (col // 3) * 3
            box_cells = (
                (r, c)
                for r in range(box_row, box_row + 3)
                for c in range(box_col, box_col + 3)
            )
            if not any(
                sum(digit in state.candidates_at(*cell) for cell in unit) == 1
                for unit in (row_cells, col_cells, box_cells)
            ):
                raise ValueError("Invalid Hidden Single")


    @staticmethod
    def _verify_subset(
        state: CandidateState, technique: LogicalTechnique, deduction: Deduction
    ) -> None:
        """Reconstruct the claimed subset and validate every proposed elimination."""
        if (deduction.technique != technique.name or deduction.placements
                or not deduction.eliminations or len(deduction.premises) != 1):
            raise ValueError("Unexpected deduction shape or technique name")
        premise = deduction.premises[0]
        size = technique.size
        if len(premise.cells) != size or len(premise.digits) != size:
            raise ValueError(f"Subset premise must identify {size} cells and {size} digits")
        cells = premise.cells
        digits = premise.digits
        board = state.board
        valid_units = []
        for _, _, unit in _units():
            if not set(cells).issubset(unit):
                continue
            if isinstance(technique, NakedSubset):
                if not all(0 < len(state.candidates_at(*cell)) <= size for cell in cells):
                    continue
                union = frozenset().union(*(state.candidates_at(*cell) for cell in cells))
                if union != digits:
                    continue
                if any(cell not in cells and state.candidates_at(*cell) and
                       state.candidates_at(*cell) <= digits for cell in unit):
                    continue
            else:
                placed = {board.value_at(*cell) for cell in unit} - {0}
                if digits & placed:
                    continue
                positions = {
                    cell for cell in unit
                    if any(digit in state.candidates_at(*cell) for digit in digits)
                }
                if positions != set(cells):
                    continue
                if any(not any(digit in state.candidates_at(*cell) for cell in cells)
                       for digit in digits):
                    continue
            valid_units.append(unit)
        if not valid_units:
            raise ValueError("Invalid pair premise" if size == 2 else "Invalid subset premise")
        for elimination in deduction.eliminations:
            if elimination.digit not in state.candidates_at(*elimination.cell):
                raise ValueError("Elimination is not an available candidate")
            if isinstance(technique, NakedSubset):
                permitted = (elimination.cell not in cells and elimination.digit in digits
                             and any(elimination.cell in unit for unit in valid_units))
            else:
                permitted = elimination.cell in cells and elimination.digit not in digits
            if not permitted:
                raise ValueError("Elimination is not justified by the subset")
